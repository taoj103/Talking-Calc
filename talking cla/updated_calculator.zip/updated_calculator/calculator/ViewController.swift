//
//  ViewController.swift
//  calculator
//
//  Created by Tony on 15/10/13.
//  Copyright (c) 2015年 Tony. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController,
    UIPickerViewDataSource, UIPickerViewDelegate {
    
    // - UIPickerView Methods
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return langCodeAll38.count
    }
    
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        let myString = "\(langCodeAll38[row].4) \(langCodeAll38[row].3)"
        
        return myString
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        currentLang = langCodeAll38[row]
        speakThisString(currentLang.3)
    }
    
    
    
    
    
    
    
    
    let mySpeechSynth = AVSpeechSynthesizer()

    var myRate: Float = 0.10
    var myPitch: Float = 0.99
    var myVolume: Float = 0.50

    var currentLang = ("en-US", "English","United States","American English ","🇺🇸")
    var currentString = ""
    var total: Int = 0
    var mode: Int = 0
    var valueString:String! = ""
    var languageString:String! = ""
    var lastButtonWasMode:Bool = false
    var totalEquals: Bool = false
    var speechVolume:Float = 1.0

    @IBAction func nextPage(sender: UIButton) {
        performSegueWithIdentifier("page2", sender: self)
        
    }
    @IBOutlet weak var label: UILabel!
    
    @IBAction func tappedMultiply(sender: AnyObject) {
        self.mode(2)
        speakThisString("Multiply")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let  mySpeechSynth = AVSpeechSynthesizer()
        // instance of AVSyth
        let myUtterance = AVSpeechUtterance(string: "Please select any of languages what you need")
        myUtterance.rate = 0.05
        myUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        mySpeechSynth.speakUtterance(myUtterance)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK - Speaking Machine
    func speakThisString(passedString: String){
        
        mySpeechSynth.stopSpeakingAtBoundary(AVSpeechBoundary.Immediate)
        
        let myUtterance = AVSpeechUtterance(string: passedString)
        myUtterance.rate = myRate
        myUtterance.pitchMultiplier = myPitch
        myUtterance.volume = myVolume
        myUtterance.voice = AVSpeechSynthesisVoice(language: currentLang.0)
        mySpeechSynth.speakUtterance(myUtterance)
        
        
        
    }

    @IBAction func tappedNumber(sender: UIButton) {
        let myString =  sender.titleLabel?.text
        currentString = myString!
        speakThisString(currentString)
        
        if (totalEquals) {
            totalEquals = false
            valueString = ""
        }
        
        let str: String! = sender.titleLabel?.text
        let num:Int! = str.toInt()
        
            
        if(num == 0 && total == 0)
        {
            return
        }
        if(lastButtonWasMode)
        {
            lastButtonWasMode = false
            valueString = ""
        }
        valueString = valueString.stringByAppendingString(str)
       
        let formatter:NSNumberFormatter = NSNumberFormatter()
        formatter.numberStyle = NSNumberFormatterStyle.DecimalStyle
        let n:NSNumber = formatter.numberFromString(valueString)!
    
        
        label.text = formatter.stringFromNumber(n)
        
        if(total == 0)
        {
            total = valueString.toInt()!
        }
        speakThisString(valueString)

        
//        let myUtterance = AVSpeechUtterance(string:str)
//            myUtterance.voice = AVSpeechSynthesisVoice(language: currentLang.0)
//        mySpeechSynth.speakUtterance(myUtterance)
    }
    
    @IBAction func tappedPlus(sender: AnyObject) {
        speakThisString("Plus")
        self.mode(1)
    }
    
    @IBAction func tappedMinus(sender: AnyObject) {
        speakThisString("Minus")
        self.mode(-1)
    }
    
    @IBAction func tappedEquals(sender: AnyObject) {
        
        if (mode == 0)
        {
            return
        }
        var iNum:Int = valueString.toInt()!
        if (mode == 1)
        {
            total += iNum
        }
        if (mode == -1)
        {
            total -= iNum
        }
        if (mode == 2)
        {
            total *= iNum
        }
        
        
        valueString = "\(total)"
        
        speakThisString("Equals")
        speakThisString(valueString)
        
        var formatter:NSNumberFormatter = NSNumberFormatter()
        formatter.numberStyle = NSNumberFormatterStyle.DecimalStyle
        var n:NSNumber = formatter.numberFromString(valueString)!
        
        
        label.text = formatter.stringFromNumber(n)
        mode = 0
        
        totalEquals = true
        
        
    }
    
    @IBAction func tappedClear(sender: AnyObject) {
        speakThisString("Clear")
        total = 0
        mode = 0
        valueString = ""
        label.text = "0"
        lastButtonWasMode = false
    }
    
    func mode(m:Int)
    {
        if(total == 0)
        {
            return
        }
        mode = m
        lastButtonWasMode = true
        total = valueString.toInt()!
        
    }
    //MARK - Calc Functions
    
    func updateLabelDisplayingNumbers(){
        label.text = currentString
    }

    
    //MARK: - Data Model
    
    // current lang array has known typos, to fix in future.
    var langCodeAll38 = [
        ("en-US",  "English", "United States", "American English","🇺🇸"),
        ("ar-SA","Arabic","Saudi Arabia","العربية","🇸🇦"),
        ("cs-CZ", "Czech", "Czech Republic","český","🇨🇿"),
        ("da-DK", "Danish","Denmark","Dansk","🇩🇰"),
        ("de-DE",       "German", "Germany", "Deutsche","🇩🇪"),
        ("el-GR",      "Modern Greek",        "Greece","ελληνική","🇬🇷"),
        ("en-AU",     "English",     "Australia","Aussie","🇦🇺"),
        ("en-GB",     "English",     "United Kingdom", "Queen's English","🇬🇧"),
        ("en-IE",      "English",     "Ireland", "Gaeilge","🇮🇪"),
        ("en-ZA",       "English",     "South Africa", "South African English","🇿🇦"),
        ("es-ES",       "Spanish",     "Spain", "Español","🇪🇸"),
        ("es-MX",       "Spanish",     "Mexico", "Español de México","🇲🇽"),
        ("fi-FI",       "Finnish",     "Finland","Suomi","🇫🇮"),
        ("fr-CA",       "French",      "Canada","Français du Canada","🇨🇦" ),
        ("fr-FR",       "French",      "France", "Français","🇫🇷"),
        ("he-IL",       "Hebrew",      "Israel","עברית","🇮🇱"),
        ("hi-IN",       "Hindi",       "India", "हिन्दी","🇮🇳"),
        ("hu-HU",       "Hungarian",    "Hungary", "Magyar","🇭🇺"),
        ("id-ID",       "Indonesian",    "Indonesia","Bahasa Indonesia","🇮🇩"),
        ("it-IT",       "Italian",     "Italy", "Italiano","🇮🇹"),
        ("ja-JP",       "Japanese",     "Japan", "日本語","🇯🇵"),
        ("ko-KR",       "Korean",      "Republic of Korea", "한국어","🇰🇷"),
        ("nl-BE",       "Dutch",       "Belgium","Nederlandse","🇧🇪"),
        ("nl-NL",       "Dutch",       "Netherlands", "Nederlands","🇳🇱"),
        ("no-NO",       "Norwegian",    "Norway", "Norsk","🇳🇴"),
        ("pl-PL",       "Polish",      "Poland", "Polski","🇵🇱"),
        ("pt-BR",       "Portuguese",      "Brazil","Portuguese","🇧🇷"),
        ("pt-PT",       "Portuguese",      "Portugal","Portuguese","🇵🇹"),
        ("ro-RO",       "Romanian",        "Romania","Română","🇷🇴"),
        ("ru-RU",       "Russian",     "Russian Federation","русский","🇷🇺"),
        ("sk-SK",       "Slovak",      "Slovakia", "Slovenčina","🇸🇰"),
        ("sv-SE",       "Swedish",     "Sweden","Svenska","🇸🇪"),
        ("th-TH",       "Thai",        "Thailand","ภาษาไทย","🇹🇭"),
        ("tr-TR",       "Turkish",     "Turkey","Türkçe","🇹🇷"),
        ("zh-CN",       "Chinese",     "China","汉语","🇨🇳"),
        ("zh-HK",       "Chinese",   "Hong Kong","粤语","🇭🇰"),
        ("zh-TW",       "Chinese",     "Taiwan","台湾汉语","🇹🇼")
    ]
    
    //Day and Night Mode
    
    @IBOutlet weak var visualControl: UISegmentedControl!
    @IBAction func myColor(sender: AnyObject) {
        
        if visualControl.selectedSegmentIndex == 0{
            speakThisString("Day Mode")
            view.backgroundColor = UIColor(red:(253/255.0), green: (203/255.0), blue: (107/255.0), alpha: 1)
        }
        
        if visualControl.selectedSegmentIndex == 1{
            speakThisString("Night Mode")
            view.backgroundColor = UIColor(red:(76/255.0), green: (76/255.0), blue: (76/255.0), alpha: 1)
        }
        
    }
    

}

